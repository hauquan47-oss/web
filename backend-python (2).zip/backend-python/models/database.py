from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin
from datetime import datetime,date, timedelta, timezone

db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()

VN_TIMEZONE = timezone(timedelta(hours=7))
def get_vn_time():
    return datetime.now(VN_TIMEZONE)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# Bảng phụ liên kết Nhiều - Nhiều (M:N) đúng kỹ thuật ORM
likes = db.Table('likes',
                 db.Column('user_id', db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), primary_key=True),
                 db.Column('post_id', db.Integer, db.ForeignKey('post.id', ondelete='CASCADE'), primary_key=True)
                 )

hearts = db.Table('hearts',
                  db.Column('user_id', db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), primary_key=True),
                  db.Column('post_id', db.Integer, db.ForeignKey('post.id', ondelete='CASCADE'), primary_key=True)
                  )


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)  # Đã bổ sung Unique Constraint
    password = db.Column(db.String(255), nullable=False)  # Nâng lên 255 dự phòng mở rộng thuật toán băm
    role = db.Column(db.String(20), default='Student') # Admin, Teacher, Student
    is_approved = db.Column(db.Boolean, default=False)

    # Hệ thống Gamification
    exp = db.Column(db.Integer, default=0)
    streak = db.Column(db.Integer, default=0)
    last_sub_date = db.Column(db.Date, nullable=True)  # Sửa thành kiểu Date chuẩn

    # 🎮 THUẬT TOÁN GAME RPG: TỰ ĐỘNG TÍNH LEVEL ĐỘNG THEO ĐƯỜNG CONG EXP
    @property
    def level(self):
        from services.gamification_service import GamificationService
        return GamificationService.calculate_level(self.exp)

    @level.setter
    def level(self, value):
        pass

    # 📊 TÍNH TỔNG SỐ EXP MÀ LEVEL HIỆN TẠI YÊU CẦU ĐỂ LÊN CẤP TIẾP THEO
    @property
    def exp_needed_for_next_level(self):
        from services.gamification_service import GamificationService
        current_lvl = self.level
        current_level_base = GamificationService.exp_needed_for_level(current_lvl)
        next_level_req = GamificationService.exp_needed_for_level(current_lvl + 1)
        return next_level_req - current_level_base

    # 🎯 TÍNH SỐ EXP HỌC SINH ĐÃ TÍCH LŨY RIÊNG TRONG CẤP ĐỘ NÀY
    @property
    def exp_in_current_level(self):
        from services.gamification_service import GamificationService
        current_lvl = self.level
        current_level_base = GamificationService.exp_needed_for_level(current_lvl)
        return self.exp - current_level_base

    # 📈 TÍNH % CO GIÃN CỦA THANH TIẾN ĐỘ LEVEL TRÊN GIAO DIỆN HTML
    @property
    def level_progress_percent(self):
        req = self.exp_needed_for_next_level
        if req == 0: return 100
        pct = int((self.exp_in_current_level / req) * 100)
        return min(max(pct, 0), 100)


    monthly_exp = db.Column(db.Integer, default=0)  # Điểm EXP tích lũy trong tháng này
    monthly_assigned_done = db.Column(db.Integer, default=0)  # Số bài tập cô giáo giao đã làm trong tháng
    monthly_personal_done = db.Column(db.Integer, default=0)  # Số bài tập tự làm trong tháng

    # Thêm mối quan hệ liên kết với kế hoạch cá nhân
    personal_plans = db.relationship('PersonalPlan', backref='student', lazy=True, cascade="all, delete-orphan")

    # Cấu hình giao diện
    dark_mode = db.Column(db.Boolean, default=False)
    mute_notif = db.Column(db.Boolean, default=False)

    # Thiết lập Cascade Delete tránh lỗi mồ côi dữ liệu khi xóa tài khoản
    posts = db.relationship('Post', backref='author', lazy=True, cascade="all, delete-orphan")
    submissions = db.relationship('Submission', backref='student', lazy=True, cascade="all, delete-orphan")
    comments = db.relationship('Comment', backref='author', lazy=True, cascade="all, delete-orphan")
    disc_comments = db.relationship('DiscussionComment', backref='author', lazy=True, cascade="all, delete-orphan")


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    image_file = db.Column(db.String(100), nullable=True)
    content = db.Column(db.Text, nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=get_vn_time)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)

    liked_by = db.relationship('User', secondary=likes, backref=db.backref('liked_posts', lazy='dynamic'))
    hearted_by = db.relationship('User', secondary=hearts, backref=db.backref('hearted_posts', lazy='dynamic'))
    comments = db.relationship('Comment', backref='post', lazy=True, cascade="all, delete-orphan")


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=get_vn_time)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)


class Subject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    assignments = db.relationship('Assignment', backref='subject', lazy=True)


class Assignment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    due_date = db.Column(db.Date, nullable=False)
    date_created = db.Column(db.DateTime, nullable=False, default=get_vn_time)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=True)
    submissions = db.relationship('Submission', backref='assignment', lazy=True, cascade="all, delete-orphan")


class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    assignment_id = db.Column(db.Integer, db.ForeignKey('assignment.id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)

    # Sửa lỗi nghiệp vụ nộp bài: Cho phép đính kèm file hoặc link nội dung bài làm
    filename = db.Column(db.String(200), nullable=True)
    content = db.Column(db.Text, nullable=True)

    # Sửa lỗi nghiệp vụ chấm điểm
    status = db.Column(db.String(20), default='Submitted')  # Submitted, Graded
    grade = db.Column(db.Float, nullable=True)
    feedback = db.Column(db.Text, nullable=True)

    date_submitted = db.Column(db.DateTime, nullable=False, default=get_vn_time)

    # Sửa lỗi bảo mật: Thêm Unique Constraint để 1 học sinh chỉ được nộp 1 bản ghi duy nhất cho 1 bài tập
    __table_args__ = (
        db.UniqueConstraint('assignment_id', 'user_id', name='uq_user_assignment'),
        db.CheckConstraint('grade >= 0 AND grade <= 10', name='check_grade_range'),
    )


class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    filename = db.Column(db.String(200), nullable=False)

    # Khắc phục lỗi vi phạm toàn vẹn tham chiếu RDBMS của Giảng viên
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    uploader = db.relationship('User', backref='uploaded_documents')

    date_uploaded = db.Column(db.DateTime, nullable=False, default=get_vn_time)


class CalendarEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    event_date = db.Column(db.Date, nullable=False)  # Sửa thành kiểu Date chuẩn
    type = db.Column(db.String(50), default='exam')  # exam, activity


class Discussion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    topic = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)

    # Khắc phục lỗi vi phạm toàn vẹn tham chiếu RDBMS
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    creator = db.relationship('User', backref='discussions')

    date_created = db.Column(db.DateTime, nullable=False, default=get_vn_time)
    comments = db.relationship('DiscussionComment', backref='discussion', lazy=True, cascade="all, delete-orphan")


# Sửa lỗi nghiệp vụ "Cụt ngọn": Cho phép mọi người thảo luận con bên trong Topic diễn đàn
class DiscussionComment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=get_vn_time)
    discussion_id = db.Column(db.Integer, db.ForeignKey('discussion.id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)


class PersonalPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)  # Tên đầu việc tự học
    description = db.Column(db.Text, nullable=True)  # Mô tả chi tiết
    is_completed = db.Column(db.Boolean, default=False)  # Trạng thái làm xong chưa
    date_created =db.Column(db.Date, default=lambda: get_vn_time().date())
    date_completed = db.Column(db.Date, nullable=True)

    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
