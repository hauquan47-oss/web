# Kế hoạch sửa lỗi và hoàn thiện hệ thống Backend Classroom (Phase 2)

Dựa trên đánh giá của Giảng viên, tôi sẽ thực hiện các thay đổi quan trọng để nâng điểm từ **6.3** lên **8.5+**.

## User Review Required

> [!IMPORTANT]
> - **Chuẩn hóa Database:** Tôi sẽ thêm bảng `Subject`. Điều này có nghĩa là các bài tập (`Assignment`) cũ có thể cần được cập nhật thủ công để chọn môn học.
> - **Security:** Loại bỏ mật khẩu mặc định `admin12345`. Bạn cần cấu hình `ADMIN_PASSWORD` trong file `.env` hoặc hệ thống sẽ không tự tạo Admin.

## Proposed Changes

### [Database & Models]

#### [MODIFY] [database.py](file:///D:/Downloads/backend-python/models/database.py)
- Thêm model `Subject` (id, name).
- Thêm `subject_id` vào `Assignment` với `ForeignKey`.
- Thêm `CheckConstraint` cho `Submission.grade` (0 đến 10).

### [Services]

#### [MODIFY] [gamification_service.py](file:///D:/Downloads/backend-python/services/gamification_service.py)
- Sửa lỗi logic streak: Không reset về 0 sau khi đạt mốc 7 để người dùng có thể đạt mốc 15, 30.

#### [MODIFY] [learning_service.py](file:///D:/Downloads/backend-python/services/learning_service.py)
- Thêm các hàm CRUD: `update_assignment`, `delete_assignment`, `delete_document`.
- Cập nhật logic tạo bài tập để hỗ trợ chọn `Subject`.

### [Routes]

#### [MODIFY] [main.py](file:///D:/Downloads/backend-python/routes/main.py)
- Refactor hàm `progress()`: Chuyển logic tính toán điểm trung bình theo môn học vào Service, sử dụng bảng `Subject` thay vì string-matching.
- Thêm Pagination cho danh sách thành viên.

#### [MODIFY] [learning.py](file:///D:/Downloads/backend-python/routes/learning.py)
- Thêm các route chỉnh sửa và xóa bài tập dành cho Giáo viên.

### [UI & Security]

#### [MODIFY] [base.html](file:///D:/Downloads/backend-python/templates/base.html)
- Sửa lỗi link Font Awesome CDN.

#### [MODIFY] [app.py](file:///D:/Downloads/backend-python/app.py)
- Loại bỏ mật khẩu admin mặc định yếu.

## Verification Plan

### Automated Tests
- Tạo thư mục `tests/` và viết các unit test cơ bản dùng `pytest` cho:
    - Logic tính Level.
    - Quyền sở hữu (Ownership) khi xóa Plan.
    - Ràng buộc điểm số (Grade constraint).

### Manual Verification
- Kiểm tra lại các trang có icon xem đã hiển thị chưa.
- Kiểm tra trang Tiến độ xem đã hiển thị theo môn học chuẩn chưa.
