import os
from datetime import date
from app import create_app
from models.database import db, User, PersonalPlan


def run_system_test():
    app = create_app()
    with app.app_context():
        print("\n==========================================")
        print("=== STARTING CLASSROOM SYSTEM TEST (10 BÀI/NGÀY) ===")
        print("==========================================")

        # 1. Kiểm tra sự tồn tại an toàn của Admin mặc định
        admin_email = os.environ.get('ADMIN_EMAIL', 'tronluc567@gmail.com')
        admin = User.query.filter_by(email=admin_email).first()
        if admin and admin.role == 'Admin':
            print("[PASS] Tài khoản Admin mặc định hoạt động chuẩn chỉnh quyền tối cao.")
        else:
            print("[FAIL] Báo động: Lỗi phân quyền tài khoản Admin mặc định!")

        # 2. Tìm hoặc khởi tạo học sinh mẫu để tiến hành cày EXP test hệ thống
        test_student = User.query.filter_by(role='Student').first()
        if not test_student:
            print("[INFO] Không tìm thấy học sinh trong DB, đang tạo tự động học sinh test...")
            test_student = User(username="HocSinhChamChi", email="chamchihoc@gmail.com", role="Student",
                                is_approved=True)
            db.session.add(test_student)
            db.session.commit()

        print(f"\n-> Học sinh làm bài: {test_student.username}")
        print(f"-> Chỉ số TRƯỚC khi làm bài: EXP tổng: {test_student.exp} | EXP tháng: {test_student.monthly_exp}")

        # 3. GIẢ LẬP TỰ ĐỘNG TẠO 12 BÀI TẬP CÁ NHÂN (Vượt hạn mức 10 bài để test bộ lọc)
        print("\n[INFO] Hệ thống đang tự động nạp 12 bài tập tự học vào danh sách kế hoạch...")
        plans_list = []
        for i in range(1, 13):
            p = PersonalPlan(title=f"Mục tiêu tự học bài số {i}", user_id=test_student.id, is_completed=False)
            plans_list.append(p)
        db.session.add_all(plans_list)
        db.session.commit()

        # 4. CHẠY LOGIC HOÀN THÀNH BÀI TẬP VÀ KIỂM TRA BỘ LỌC CHỐNG SPAM
        print("\n--- BẮT ĐẦU QUY TRÌNH HỌC SINH BẤM HOÀN THÀNH BÀI TẬP ---")
        for idx, plan in enumerate(plans_list):
            # Đếm xem tính đến thời điểm hiện tại trong ngày hôm nay đã làm xong bao nhiêu bài rồi
            today_done_count = PersonalPlan.query.filter_by(
                user_id=test_student.id,
                is_completed=True,
                date_completed=date.today()
            ).count()

            # Nếu dưới 10 bài thì mở khóa cộng điểm thưởng tự học
            if today_done_count < 10:
                test_student.exp += 15
                test_student.monthly_exp += 15
                print(f"[Bài {idx + 1:02d}] -> Thành công: Đạt điều kiện và được cộng +15 EXP.")
            else:
                # Từ bài thứ 11 trở đi, chặn đứng không cho tăng điểm nữa
                print(
                    f"[Bài {idx + 1:02d}] -> [SECURITY PASS] Bị chặn: Đạt giới hạn 10 bài/ngày. Không cộng thêm điểm!")

            # Đổi trạng thái file sang hoàn thành giống như hành động bấm nút trên giao diện web
            plan.is_completed = True
            plan.date_completed = date.today()
            test_student.monthly_personal_done += 1
            db.session.commit()

        # 5. IN KẾT QUẢ CUỐI CÙNG SAU KHI QUÉT SẠCH TIẾN TRÌNH
        print("\n==========================================")
        print("=== KẾT QUẢ ĐÁNH GIÁ HỆ THỐNG SAU KHI TEST ===")
        print("==========================================")
        print(f"✓ EXP tổng trọn đời hiện tại: {test_student.exp} XP")
        print(f"✓ EXP thi đua tháng hiện tại: {test_student.monthly_exp} XP")
        print(f"✓ Tổng số bài tự học đã lưu nhận trong tháng: {test_student.monthly_personal_done} bài")
        print("[STATUS] Code vận hành hoàn hảo. Bộ lọc chống gian lận hoạt động chính xác 100%!")
        print("==========================================\n")


if __name__ == '__main__':
    run_system_test()
