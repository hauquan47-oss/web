from models.database import db
from utils.constants import STREAK_BONUS_EXP, LEVEL_BASE_EXP, LEVEL_EXP_EXPONENT

class GamificationService:
    @staticmethod
    def calculate_level(exp):
        if exp < LEVEL_BASE_EXP:
            return 1
        return int((exp / LEVEL_BASE_EXP) ** (1 / LEVEL_EXP_EXPONENT)) + 1

    @staticmethod
    def exp_needed_for_level(level):
        if level <= 1:
            return 0
        return int(LEVEL_BASE_EXP * ((level - 1) ** LEVEL_EXP_EXPONENT))

    @staticmethod
    def update_streak_and_exp(user, today_obj, earned_exp):
        new_streak = user.streak

        if user.last_sub_date:
            diff = (today_obj - user.last_sub_date).days
            if diff == 1:
                new_streak += 1
            elif diff > 1:
                new_streak = 1
        else:
            new_streak = 1

        if new_streak >= 7 and new_streak % 7 == 0:
            earned_exp += STREAK_BONUS_EXP
            # Không reset streak để người dùng có thể đạt mốc 15, 30 ngày.

        user.streak = new_streak
        user.last_sub_date = today_obj
        user.exp += earned_exp
        user.monthly_exp += earned_exp
        return earned_exp
