import os
import uuid
from flask import current_app
from models.database import db, Post, Comment
from utils.exceptions import BusinessError

class PostService:
    @staticmethod
    def _allowed_file(filename):
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

    @staticmethod
    def create_post(user, content, file):
        if len(content) > 5000:
            raise BusinessError('Nội dung bài viết quá dài (Tối đa 5000 ký tự).')

        filename = None
        if file and file.filename != '':
            if PostService._allowed_file(file.filename):
                ext = file.filename.rsplit('.', 1)[1].lower()
                filename = f"{uuid.uuid4().hex}.{ext}"
                file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
            else:
                raise BusinessError('Định dạng tệp tin ảnh tải lên không hợp lệ!')

        post = Post(content=content, image_file=filename, author=user)
        db.session.add(post)
        db.session.commit()
        return post

    @staticmethod
    def toggle_like(user, post_id):
        post = Post.query.get_or_404(post_id)
        if user in post.liked_by:
            post.liked_by.remove(user)
            status = 'unliked'
        else:
            post.liked_by.append(user)
            status = 'liked'
        db.session.commit()
        return status, len(post.liked_by)

    @staticmethod
    def toggle_heart(user, post_id):
        post = Post.query.get_or_404(post_id)
        if user in post.hearted_by:
            post.hearted_by.remove(user)
            status = 'unhearted'
        else:
            post.hearted_by.append(user)
            status = 'hearted'
        db.session.commit()
        return status, len(post.hearted_by)

    @staticmethod
    def add_comment(user, post_id, content):
        if not content or len(content) > 1000:
             raise BusinessError('Nội dung bình luận không hợp lệ.')

        comment = Comment(content=content, post_id=post_id, author=user)
        db.session.add(comment)
        db.session.commit()
        return comment
