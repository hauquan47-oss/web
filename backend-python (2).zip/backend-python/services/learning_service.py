import os
import uuid
from datetime import datetime
from flask import current_app
from models.database import db, Assignment, Submission, Document, Discussion, DiscussionComment, PersonalPlan, CalendarEvent, Subject
from utils.exceptions import BusinessError
from utils.constants import EXP_PER_PLAN, MAX_PLANS_PER_DAY, ASSIGNMENT_EXP
from services.gamification_service import GamificationService
from sqlalchemy import func

class LearningService:
    @staticmethod
    def _allowed_file(filename):
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

    @staticmethod
    def create_assignment(title, description, due_date_obj, subject_id=None):
        assign = Assignment(title=title, description=description, due_date=due_date_obj, subject_id=subject_id)
        db.session.add(assign)
        db.session.commit()
        return assign

    @staticmethod
    def update_assignment(assign_id, title, description, due_date_obj, subject_id=None):
        assign = Assignment.query.get_or_404(assign_id)
        assign.title = title
        assign.description = description
        assign.due_date = due_date_obj
        assign.subject_id = subject_id
        db.session.commit()
        return assign

    @staticmethod
    def delete_assignment(assign_id):
        assign = Assignment.query.get_or_404(assign_id)
        db.session.delete(assign)
        db.session.commit()

    @staticmethod
    def get_all_subjects():
        return Subject.query.all()

    @staticmethod
    def create_subject(name):
        if Subject.query.filter_by(name=name).first():
            raise BusinessError("Môn học này đã tồn tại.")
        subject = Subject(name=name)
        db.session.add(subject)
        db.session.commit()
        return subject

    @staticmethod
    def delete_document(user_id, doc_id, user_role):
        doc = Document.query.get_or_404(doc_id)
        if user_role not in ['Admin', 'Teacher'] and doc.user_id != user_id:
            raise BusinessError("Bạn không có quyền xóa tài liệu này.", 403)

        # Xóa file vật lý
        file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], doc.filename)
        if os.path.exists(file_path):
            os.remove(file_path)

        db.session.delete(doc)
        db.session.commit()

    @staticmethod
    def calculate_progress(user):
        total_assignments = Assignment.query.count()
        my_subs = Submission.query.filter_by(user_id=user.id).all()
        completed_count = len(my_subs)
        progress_rate = int((completed_count / total_assignments) * 100) if total_assignments > 0 else 0
        total_hours = round((completed_count * 1.2) + (user.monthly_personal_done * 0.5), 1)

        subjects = Subject.query.all()
        subject_progress = []

        for sub in subjects:
            # Lấy các bài nộp của môn học này
            sub_grades = [s.grade for s in my_subs if s.assignment.subject_id == sub.id and s.status == 'Graded' and s.grade is not None]

            if sub_grades:
                avg_grade = sum(sub_grades) / len(sub_grades)
                pct = int((avg_grade / 10) * 100)
            else:
                pct = 0 # Default if no grades

            pct = max(min(pct, 100), 0)
            subject_progress.append({'name': sub.name, 'pct': pct})

        return {
            'completed_count': completed_count,
            'progress_rate': progress_rate,
            'total_hours': total_hours,
            'subject_progress': subject_progress
        }

    @staticmethod
    def create_calendar_event(title, event_date, event_type):
        event = CalendarEvent(title=title, event_date=event_date, type=event_type)
        db.session.add(event)
        db.session.commit()
        return event

    @staticmethod
    def submit_assignment(user, assign_id, content, file, today_obj):
        existing_sub = Submission.query.filter_by(assignment_id=assign_id, user_id=user.id).first()
        if existing_sub:
            raise BusinessError('Bạn đã hoàn thành nộp bài tập này từ trước, không thể nộp lại nhiều lần!')

        filename = None
        if file and file.filename != '':
            if LearningService._allowed_file(file.filename):
                ext = file.filename.rsplit('.', 1)[1].lower()
                filename = f"sub_{uuid.uuid4().hex}.{ext}"
                file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
            else:
                raise BusinessError('Định dạng file nộp bài không nằm trong danh mục cho phép!')

        sub = Submission(
            assignment_id=assign_id,
            user_id=user.id,
            filename=filename,
            content=content,
            status='Submitted'
        )

        GamificationService.update_streak_and_exp(user, today_obj, ASSIGNMENT_EXP)
        user.monthly_assigned_done += 1

        db.session.add(sub)
        db.session.commit()
        return sub

    @staticmethod
    def grade_submission(sub_id, grade, feedback):
        sub = Submission.query.get_or_404(sub_id)
        sub.grade = grade
        sub.feedback = feedback
        sub.status = 'Graded'
        db.session.commit()
        return sub

    @staticmethod
    def upload_document(user_id, title, file):
        if not file or file.filename == '':
            raise BusinessError('Vui lòng chọn file tài liệu.')

        if not LearningService._allowed_file(file.filename):
            raise BusinessError('File upload không an toàn hoặc không đúng định dạng cho phép!')

        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = f"doc_{uuid.uuid4().hex}.{ext}"
        file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))

        doc = Document(title=title, filename=filename, user_id=user_id)
        db.session.add(doc)
        db.session.commit()
        return doc

    @staticmethod
    def create_discussion(user_id, topic, content):
        disc = Discussion(topic=topic, content=content, user_id=user_id)
        db.session.add(disc)
        db.session.commit()
        return disc

    @staticmethod
    def add_discussion_comment(user_id, disc_id, content):
        if not content:
            raise BusinessError('Nội dung bình luận không được để trống.')
        cm = DiscussionComment(content=content, discussion_id=disc_id, user_id=user_id)
        db.session.add(cm)
        db.session.commit()
        return cm

    @staticmethod
    def create_personal_plan(user_id, title, description):
        if not title:
            raise BusinessError('Tiêu đề kế hoạch không được để trống.')
        plan = PersonalPlan(title=title, description=description, user_id=user_id)
        db.session.add(plan)
        db.session.commit()
        return plan

    @staticmethod
    def complete_personal_plan(user, plan_id, today_date):
        plan = PersonalPlan.query.get_or_404(plan_id)

        if plan.user_id != user.id:
            raise BusinessError('Bạn không có quyền thao tác trên kế hoạch của người khác!', 403)

        if plan.is_completed:
            raise BusinessError('Kế hoạch này bạn đã hoàn thành từ trước rồi!')

        today_done_count = PersonalPlan.query.filter(
            PersonalPlan.user_id == user.id,
            PersonalPlan.is_completed == True,
            func.date(PersonalPlan.date_completed) == today_date
        ).count()

        earned_exp = 0
        if today_done_count < MAX_PLANS_PER_DAY:
            earned_exp = EXP_PER_PLAN
            user.exp += earned_exp
            user.monthly_exp += earned_exp

        plan.is_completed = True
        plan.date_completed = today_date
        user.monthly_personal_done += 1

        db.session.commit()
        return plan, earned_exp

    @staticmethod
    def delete_personal_plan(user_id, plan_id):
        plan = PersonalPlan.query.get_or_404(plan_id)

        if plan.user_id != user_id:
            raise BusinessError('Hành động trái phép!', 403)

        db.session.delete(plan)
        db.session.commit()
