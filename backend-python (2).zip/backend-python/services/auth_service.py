import os
from models.database import db, bcrypt, User
from utils.exceptions import BusinessError
from flask_login import login_user

class AuthService:
    @staticmethod
    def register_user(username, email, password, role, teacher_code):
        username = username.strip()
        email = email.strip().lower()

        if not email.endswith('@gmail.com'):
            raise BusinessError('Hệ thống lớp học chỉ chấp nhận tài khoản có đuôi @gmail.com hợp lệ!')

        if User.query.filter_by(username=username).first():
            raise BusinessError('Tên tài khoản này đã tồn tại!')

        if User.query.filter_by(email=email).first():
            raise BusinessError('Địa chỉ Email này đã được đăng ký sử dụng!')

        # Role consistency
        if role not in ['Admin', 'Teacher', 'Student']:
            role = 'Student'

        if role == 'Teacher':
            if teacher_code != os.environ.get('TEACHER_VERIFICATION_CODE'):
                role = 'Student'
        elif role == 'Admin':
            role = 'Student' # Locked registration for Admin

        hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')
        is_app = True if role == 'Admin' else False

        user = User(username=username, email=email, password=hashed_pw, role=role, is_approved=is_app)
        db.session.add(user)
        db.session.commit()
        return user

    @staticmethod
    def login_user(email, password):
        email = email.strip()
        user = User.query.filter_by(email=email).first()

        if user and bcrypt.check_password_hash(user.password, password):
            if not user.is_approved:
                raise BusinessError('Tài khoản của bạn đang trong hàng chờ kiểm tra từ Giáo viên để tránh nick ảo.')
            login_user(user)
            return user
        else:
            raise BusinessError('Đăng nhập thất bại. Vui lòng kiểm tra lại thông tin.')

    @staticmethod
    def update_profile(user, new_username):
        new_username = new_username.strip()
        if new_username != user.username:
            if User.query.filter_by(username=new_username).first():
                raise BusinessError('Tên người dùng này đã có người khác chọn sử dụng!')
            user.username = new_username
            db.session.commit()

    @staticmethod
    def delete_account(user, confirm_password):
        if not bcrypt.check_password_hash(user.password, confirm_password):
            raise BusinessError('Mật khẩu xác nhận không chính xác! Hành động xóa tài khoản bị chặn.')

        db.session.delete(user)
        db.session.commit()

    @staticmethod
    def approve_user(user_id):
        user = User.query.get_or_404(user_id)
        user.is_approved = True
        db.session.commit()
        return user

    @staticmethod
    def reject_user(user_id):
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
