from datetime import datetime, timedelta, timezone

VN_TIMEZONE = timezone(timedelta(hours=7))

def get_vn_time():
    return datetime.now(VN_TIMEZONE)

def get_vn_today():
    return get_vn_time().date()
