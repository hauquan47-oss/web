import os
from flask import Flask, render_template, flash, redirect, url_for, request
from config import Config
from models.database import db, bcrypt, login_manager
from extensions import csrf, limiter
from flask_talisman import Talisman

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Khởi tạo các thư viện mở rộng hệ thống
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    # Talisman giúp thêm các Header bảo mật (CSP, HSTS, XSS Protection)
    # Lưu ý: Cấu hình content_security_policy=None để tránh chặn script/style nội bộ nếu chưa tối ưu
    Talisman(app, content_security_policy=None, force_https=False)

    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Vui lòng đăng nhập để truy cập hệ thống lớp học.'
    login_manager.login_message_category = 'warning'

    # Tự động tạo thư mục upload an toàn nếu chưa tồn tại
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

    # Đăng ký các Blueprint điều hướng luồng nghiệp vụ
    from routes.auth import auth_bp
    from routes.main import main_bp
    from routes.learning import learning_bp
    from routes.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(learning_bp)
    app.register_blueprint(admin_bp)

    # Khởi tạo cơ sở dữ liệu và tài khoản quản trị viên hệ thống
    with app.app_context():
        db.create_all()

        # Thiết lập tài khoản Admin mặc định an toàn
        from models.database import User
        admin_email = os.environ.get('ADMIN_EMAIL', 'tronluc567@gmail.com')
        admin_user = User.query.filter_by(email=admin_email).first()
        if not admin_user:
            admin_password = os.environ.get('ADMIN_PASSWORD')
            if not admin_password:
                # Không có password trong môi trường -> Không tạo admin mặc định để tránh mật khẩu yếu
                print("CẢNH BÁO: Không tìm thấy ADMIN_PASSWORD. Tài khoản quản trị viên mặc định chưa được tạo.")
            else:
                hashed_pw = bcrypt.generate_password_hash(admin_password).decode('utf-8')
                default_admin = User(
                    username='Quản Trị Viên',
                    email=admin_email,
                    password=hashed_pw,
                    role='Admin',
                    is_approved=True,
                    exp = 32000000,
                    streak = 365,
                )
                db.session.add(default_admin)
                db.session.commit()

        # Tạo các môn học mặc định nếu chưa có
        from models.database import Subject
        default_subjects = ['Toán học', 'Ngữ văn', 'Tiếng Anh', 'Tin học', 'Vật lý', 'Hóa học', 'Địa lý']
        for sub_name in default_subjects:
            if not Subject.query.filter_by(name=sub_name).first():
                db.session.add(Subject(name=sub_name))
        db.session.commit()
    from utils.exceptions import BusinessError
    from flask import render_template, flash, redirect, url_for

    @app.errorhandler(BusinessError)
    def handle_business_error(e):
        flash(e.message, 'danger')
        # This is a bit tricky since we don't know where to redirect.
        # But usually BusinessError is handled within the route.
        # If it bubbles up here, it might be a generic handler.
        return redirect(request.referrer or url_for('main.dashboard'))

    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('404.html'), 404

    # @app.errorhandler(500)
    # def internal_server_error(e):
    #     return render_template('500.html'), 500

    return app


if __name__ == '__main__':
    app = create_app()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
