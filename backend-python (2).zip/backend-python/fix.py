import os
from dotenv import load_dotenv
from app import create_app
from models.database import db, Assignment, Submission

# Nạp file cấu hình môi trường chuẩn chỉnh 100%
load_dotenv()

app = create_app()
with app.app_context():
    try:
        # Xóa sạch lịch sử nộp bài cũ để tránh nghẽn mạch
        db.session.query(Submission).delete()

        # Xóa sạch các bài tập lớp bị lỗi cũ trong database
        db.session.query(Assignment).delete()

        db.session.commit()
        print("=======================================================")
        print("🎉 XÓA BÀI TẬP LỖI CŨ THÀNH CÔNG! TRANG WEB ĐÃ SẠCH SẼ.")
        print("=======================================================")
    except Exception as e:
        db.session.rollback()
        print(f"Có lỗi xảy ra: {e}")
