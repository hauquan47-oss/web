from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, current_user, login_required
from services.auth_service import AuthService
from utils.exceptions import BusinessError
from extensions import limiter

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['GET', 'POST'])
@limiter.limit("20 per hour") # Chống Spam tài khoản ảo (đã nới lỏng để test)
def register():
    # ...
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        username = request.form.get('username', '')
        email = request.form.get('email', '')
        password = request.form.get('password')
        role = request.form.get('role', 'Student')
        teacher_code = request.form.get('teacher_code', '')

        try:
            AuthService.register_user(username, email, password, role, teacher_code)
            flash('Tài khoản đã tạo thành công! Vui lòng chờ Giáo viên hoặc Quản trị viên duyệt hồ sơ.', 'success')
            return redirect(url_for('auth.login'))
        except BusinessError as e:
            flash(e.message, 'danger')

    return render_template('register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
@limiter.limit("30 per minute") # Chống Brute Force: Chỉ cho phép thử 30 lần/phút (đã nới lỏng)
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        email = request.form.get('email', '')
        password = request.form.get('password')
        try:
            AuthService.login_user(email, password)
            return redirect(url_for('main.dashboard'))
        except BusinessError as e:
            flash(e.message, 'danger')

    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))
