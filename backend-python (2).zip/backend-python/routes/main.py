from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from models.database import User, Post, CalendarEvent, PersonalPlan, Assignment, Submission
from flask_login import current_user, login_required
from services.post_service import PostService
from services.auth_service import AuthService
from services.learning_service import LearningService
from utils.exceptions import BusinessError
from utils.time_utils import get_vn_today

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
@main_bp.route('/dashboard')
@login_required
def dashboard():
    today_obj = get_vn_today()
    upcoming_events = CalendarEvent.query.filter(CalendarEvent.event_date >= today_obj).order_by(
        CalendarEvent.event_date.asc()).limit(3).all()

    my_pending_plans = PersonalPlan.query.filter_by(user_id=current_user.id, is_completed=False).order_by(
        PersonalPlan.date_created.desc()).limit(3).all()

    top_students_month = User.query.filter_by(is_approved=True, role='Student').order_by(User.monthly_exp.desc()).limit(
        3).all()

    total_assignments = Assignment.query.count()
    completed = len(current_user.submissions)
    progress_pct = int((completed / total_assignments) * 100) if total_assignments > 0 else 0

    return render_template(
        'dashboard.html',
        progress_pct=progress_pct,
        completed=completed,
        total=total_assignments,
        upcoming_events=upcoming_events,
        my_pending_plans=my_pending_plans,
        top_students_month=top_students_month
    )

@main_bp.route('/feed', methods=['GET', 'POST'])
@login_required
def feed():
    if request.method == 'POST':
        content = request.form.get('content', '').strip()
        file = request.files.get('image')
        try:
            PostService.create_post(current_user, content, file)
        except BusinessError as e:
            flash(e.message, 'danger')
        return redirect(url_for('main.feed'))

    page = request.args.get('page', 1, type=int)
    posts_pagination = Post.query.order_by(Post.date_posted.desc()).paginate(page=page, per_page=5, error_out=False)
    return render_template('feed.html', posts_pagination=posts_pagination)

@main_bp.route('/post/<int:post_id>/like')
@login_required
def like_post(post_id):
    status, count = PostService.toggle_like(current_user, post_id)
    return jsonify({'status': status, 'like_count': count})

@main_bp.route('/post/<int:post_id>/heart')
@login_required
def heart_post(post_id):
    status, count = PostService.toggle_heart(current_user, post_id)
    return jsonify({'status': status, 'heart_count': count})

@main_bp.route('/post/<int:post_id>/comment', methods=['POST'])
@login_required
def add_comment(post_id):
    content = request.form.get('content', '').strip()
    try:
        PostService.add_comment(current_user, post_id, content)
    except BusinessError as e:
        flash(e.message, 'danger')
    return redirect(url_for('main.feed'))

@main_bp.route('/members')
@login_required
def members():
    page = request.args.get('page', 1, type=int)

    # Lấy danh sách chờ duyệt (chỉ cho Giáo viên/Admin)
    pending_users = []
    if current_user.role in ['Admin', 'Teacher']:
        pending_users = User.query.filter_by(is_approved=False).order_by(User.id.desc()).all()

    # Lấy danh sách chính thức và phân trang
    users = User.query.filter_by(is_approved=True).all()
    users = sorted(users, key=lambda x: x.exp, reverse=True)

    start = (page - 1) * 10
    end = start + 10
    users_list = users[start:end]
    has_next = len(users) > end

    return render_template('members.html',
                           users=users_list,
                           pending_users=pending_users,
                           page=page,
                           has_next=has_next)

@main_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        if 'delete_acc' in request.form:
            confirm_pw = request.form.get('confirm_password')
            try:
                AuthService.delete_account(current_user, confirm_pw)
                flash('Tài khoản của bạn đã được xóa khỏi hệ thống.', 'info')
                return redirect(url_for('auth.register'))
            except BusinessError as e:
                flash(e.message, 'danger')
                return redirect(url_for('main.profile'))

        new_username = request.form.get('username', '').strip()
        try:
            AuthService.update_profile(current_user, new_username)
            flash('Cập nhật hồ sơ cá nhân thành công!', 'success')
        except BusinessError as e:
            flash(e.message, 'danger')

    return render_template('profile.html')

@main_bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        from models.database import db
        current_user.dark_mode = True if request.form.get('dark_mode') else False
        current_user.mute_notif = True if request.form.get('mute_notif') else False
        db.session.commit()
        flash('Đã lưu cấu hình thiết lập hệ thống.', 'success')
    return render_template('settings.html')

@main_bp.route('/progress')
@login_required
def progress():
    # Sử dụng LearningService để tính toán tiến độ chuẩn hóa
    progress_data = LearningService.calculate_progress(current_user)

    my_pending_plans = PersonalPlan.query.filter_by(
        user_id=current_user.id,
        is_completed=False
    ).order_by(PersonalPlan.date_created.desc()).all()

    my_completed_plans = PersonalPlan.query.filter_by(
        user_id=current_user.id,
        is_completed=True
    ).order_by(PersonalPlan.date_completed.desc()).all()

    top_students = User.query.filter_by(role='Student', is_approved=True) \
        .order_by(User.monthly_assigned_done.desc()).all()

    return render_template(
        'progress.html',
        subject_progress=progress_data['subject_progress'],
        completed_count=progress_data['completed_count'],
        progress_rate=progress_data['progress_rate'],
        total_hours=progress_data['total_hours'],
        my_pending_plans=my_pending_plans,
        my_completed_plans=my_completed_plans,
        top_students=top_students
    )
