from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, flash
from models.database import CalendarEvent, User
from utils.decorators import role_required
from flask_login import login_required, current_user
from services.auth_service import AuthService
from services.learning_service import LearningService
from utils.exceptions import BusinessError

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/calendar', methods=['GET', 'POST'])
@login_required
def calendar():
    if request.method == 'POST':
        if current_user.role not in ['Admin', 'Teacher']:
            flash('Bạn không có quyền thêm lịch.', 'danger')
            return redirect(url_for('admin.calendar'))

        title = request.form.get('title', '').strip()
        event_date_str = request.form.get('event_date')
        type_ev = request.form.get('type')

        try:
            date_obj = datetime.strptime(event_date_str, '%Y-%m-%d').date()
            LearningService.create_calendar_event(title, date_obj, type_ev)
            flash('Đã cập nhật sự kiện lịch mới cho lớp học.', 'success')
        except (ValueError, BusinessError):
            flash('Lỗi định dạng dữ liệu ngày tháng hoặc nghiệp vụ.', 'danger')
        return redirect(url_for('admin.calendar'))

    events = CalendarEvent.query.order_by(CalendarEvent.event_date.asc()).all()
    return render_template('calendar.html', events=events)

@admin_bp.route('/approve_user/<int:user_id>')
@role_required('Admin', 'Teacher')
def approve_user(user_id):
    try:
        user = AuthService.approve_user(user_id)
        flash(f'Đã phê duyệt tài khoản {user.username} vào lớp học.', 'success')
    except BusinessError as e:
        flash(e.message, 'danger')
    return redirect(url_for('main.members'))

@admin_bp.route('/reject_user/<int:user_id>')
@role_required('Admin', 'Teacher')
def reject_user(user_id):
    try:
        AuthService.reject_user(user_id)
        flash(f'Đã xóa bỏ tài khoản ảo.', 'info')
    except BusinessError as e:
        flash(e.message, 'danger')
    return redirect(url_for('main.members'))

@admin_bp.route('/approve_list')
@login_required
def approve_list():
    if current_user.role not in ['Admin', 'Teacher']:
        flash('Bạn không có quyền truy cập trang phê duyệt thành viên!', 'danger')
        return redirect(url_for('main.dashboard'))

    pending_users = User.query.filter_by(is_approved=False).order_by(User.id.desc()).all()
    return render_template('approve.html', pending_users=pending_users)
