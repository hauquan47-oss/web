import datetime as dt
from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from models.database import Assignment, Submission, Document, Discussion, PersonalPlan
from utils.decorators import role_required
from flask_login import current_user, login_required
from services.learning_service import LearningService
from utils.exceptions import BusinessError
from utils.time_utils import get_vn_today

learning_bp = Blueprint('learning', __name__)

@learning_bp.route('/assignments', methods=['GET', 'POST'])
@login_required
def assignments():
    if request.method == 'POST':
        if current_user.role not in ['Admin', 'Teacher']:
            flash('Bạn không có quyền thực hiện chức năng này.', 'danger')
            return redirect(url_for('learning.assignments'))

        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        due_date_str = request.form.get('due_date')
        subject_id = request.form.get('subject_id', type=int)

        try:
            due_date_obj = dt.datetime.strptime(due_date_str, '%Y-%m-%d').date()
            LearningService.create_assignment(title, description, due_date_obj, subject_id)
            flash('Đã đăng bài tập mới cho cả lớp.', 'success')
        except (ValueError, BusinessError) as e:
            flash(getattr(e, 'message', 'Định dạng thời gian hoặc dữ liệu bị sai lệch.'), 'danger')
        return redirect(url_for('learning.assignments'))

    assigns = Assignment.query.order_by(Assignment.id.desc()).all()
    subjects = LearningService.get_all_subjects()
    return render_template('assignments.html', assigns=assigns, subjects=subjects)

@learning_bp.route('/assignments/<int:assign_id>/edit', methods=['GET', 'POST'])
@role_required('Admin', 'Teacher')
def edit_assignment(assign_id):
    assign = Assignment.query.get_or_404(assign_id)
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        due_date_str = request.form.get('due_date')
        subject_id = request.form.get('subject_id', type=int)

        try:
            due_date_obj = dt.datetime.strptime(due_date_str, '%Y-%m-%d').date()
            LearningService.update_assignment(assign_id, title, description, due_date_obj, subject_id)
            flash('Cập nhật bài tập thành công.', 'success')
            return redirect(url_for('learning.assignment_detail', assign_id=assign_id))
        except (ValueError, BusinessError) as e:
            flash(getattr(e, 'message', 'Lỗi dữ liệu.'), 'danger')

    subjects = LearningService.get_all_subjects()
    return render_template('edit_assignment.html', assign=assign, subjects=subjects)

@learning_bp.route('/assignments/<int:assign_id>/delete', methods=['POST'])
@role_required('Admin', 'Teacher')
def delete_assignment(assign_id):
    try:
        LearningService.delete_assignment(assign_id)
        flash('Đã xóa bài tập.', 'info')
    except BusinessError as e:
        flash(e.message, 'danger')
    return redirect(url_for('learning.assignments'))

@learning_bp.route('/subjects', methods=['GET', 'POST'])
@role_required('Admin', 'Teacher')
def manage_subjects():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        try:
            LearningService.create_subject(name)
            flash(f'Đã thêm môn học: {name}', 'success')
        except BusinessError as e:
            flash(e.message, 'danger')
        return redirect(url_for('learning.manage_subjects'))

    subjects = LearningService.get_all_subjects()
    return render_template('manage_subjects.html', subjects=subjects)

@learning_bp.route('/documents/<int:doc_id>/delete', methods=['POST'])
@login_required
def delete_document(doc_id):
    try:
        LearningService.delete_document(current_user.id, doc_id, current_user.role)
        flash('Đã xóa tài liệu.', 'info')
    except BusinessError as e:
        flash(e.message, 'danger')
    return redirect(url_for('learning.documents'))

@learning_bp.route('/assignments/<int:assign_id>', methods=['GET'])
@login_required
def assignment_detail(assign_id):
    assign = Assignment.query.get_or_404(assign_id)
    subs = []
    if current_user.role in ['Teacher', 'Admin']:
        subs = Submission.query.filter_by(assignment_id=assign_id).all()
    return render_template('assignment_detail.html', assign=assign, subs=subs)

@learning_bp.route('/assignments/<int:assign_id>/submit', methods=['POST'])
@login_required
def submit_assignment(assign_id):
    content = request.form.get('content', '').strip()
    file = request.files.get('sub_file')
    today_obj = get_vn_today()

    try:
        sub = LearningService.submit_assignment(current_user, assign_id, content, file, today_obj)
        flash(f'Nộp bài thành công! Hệ hệ thống ghi nhận chuỗi hành động.', 'success')
        return redirect(url_for('learning.assignment_detail', assign_id=sub.assignment_id))
    except BusinessError as e:
        flash(e.message, 'danger')
        return redirect(url_for('learning.assignments'))

@learning_bp.route('/assignments/grade/<int:sub_id>', methods=['POST'])
@role_required('Teacher', 'Admin')
def grade_submission(sub_id):
    grade = request.form.get('grade', type=float)
    feedback = request.form.get('feedback', '').strip()

    try:
        sub = LearningService.grade_submission(sub_id, grade, feedback)
        flash(f'Đã chấm điểm thành công cho bài làm của {sub.student.username}.', 'success')
        return redirect(url_for('learning.assignment_detail', assign_id=sub.assignment_id))
    except BusinessError as e:
        flash(e.message, 'danger')
        return redirect(url_for('learning.assignments'))

@learning_bp.route('/documents', methods=['GET', 'POST'])
@login_required
def documents():
    if request.method == 'POST':
        file = request.files.get('doc_file')
        title = request.form.get('title', '').strip()
        try:
            LearningService.upload_document(current_user.id, title, file)
            flash('Tải tài liệu lên kho lưu trữ thành công.', 'success')
        except BusinessError as e:
            flash(e.message, 'danger')
        return redirect(url_for('learning.documents'))

    docs = Document.query.all()
    return render_template('documents.html', docs=docs)

@learning_bp.route('/discuss', methods=['GET', 'POST'])
@login_required
def discuss():
    if request.method == 'POST':
        topic = request.form.get('topic', '').strip()
        content = request.form.get('content', '').strip()
        try:
            LearningService.create_discussion(current_user.id, topic, content)
            flash('Chủ đề thảo luận đã được tạo.', 'success')
        except BusinessError as e:
            flash(e.message, 'danger')
        return redirect(url_for('learning.discuss'))

    discussions = Discussion.query.order_by(Discussion.date_created.desc()).all()
    return render_template('discuss.html', discussions=discussions)

@learning_bp.route('/discuss/<int:disc_id>', methods=['GET', 'POST'])
@login_required
def discuss_detail(disc_id):
    disc = Discussion.query.get_or_404(disc_id)
    if request.method == 'POST':
        content = request.form.get('content', '').strip()
        try:
            LearningService.add_discussion_comment(current_user.id, disc_id, content)
        except BusinessError as e:
            flash(e.message, 'danger')
        return redirect(url_for('learning.discuss_detail', disc_id=disc_id))
    return render_template('discussion_detail.html', disc=disc)

@learning_bp.route('/achievements')
@login_required
def achievements():
    total_completed = len(current_user.submissions)
    has_cup = total_completed >= 20
    fire_color = 'none'
    if current_user.streak >= 30:
        fire_color = 'purple'
    elif current_user.streak >= 15:
        fire_color = 'red'
    elif current_user.streak >= 7:
        fire_color = 'orange'
    return render_template('achievements.html', has_cup=has_cup, fire_color=fire_color)

@learning_bp.route('/personal_plans', methods=['GET', 'POST'])
@login_required
def personal_plans():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        try:
            LearningService.create_personal_plan(current_user.id, title, description)
            flash('Đã thêm một mục kế hoạch học tập cá nhân mới!', 'success')
        except BusinessError as e:
            flash(e.message, 'danger')
        return redirect(url_for('learning.personal_plans'))

    plans = PersonalPlan.query.filter_by(user_id=current_user.id).order_by(PersonalPlan.is_completed.asc(),
                                                                           PersonalPlan.date_created.desc()).all()
    return render_template('personal_plans.html', plans=plans)

@learning_bp.route('/personal_plans/<int:plan_id>/complete')
@login_required
def complete_personal_plan(plan_id):
    today_date = get_vn_today()
    try:
        plan, earned_exp = LearningService.complete_personal_plan(current_user, plan_id, today_date)
        if earned_exp > 0:
            flash(f'Chúc mừng! Hoàn thành kế hoạch cá nhân và nhận được {earned_exp} EXP tự học.', 'success')
        else:
            flash('Hôm nay bạn đã hoàn thành tối đa điểm EXP tự học rồi. Bài này sẽ được ghi nhận hoàn thành nhưng không cộng thêm điểm nhé!', 'info')
    except BusinessError as e:
        flash(e.message, 'danger')

    if request.referrer and 'dashboard' in request.referrer:
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('learning.personal_plans'))

@learning_bp.route('/personal_plans/<int:plan_id>/delete', methods=['POST'])
@login_required
def delete_personal_plan(plan_id):
    try:
        LearningService.delete_personal_plan(current_user.id, plan_id)
        return jsonify({'status': 'success', 'message': 'Đã xóa mục tiêu khỏi danh sách!'})
    except BusinessError as e:
        return jsonify({'status': 'error', 'message': e.message}), e.status_code
    except Exception:
        return jsonify({'status': 'error', 'message': 'Lỗi kết nối cơ sở dữ liệu.'}), 500
