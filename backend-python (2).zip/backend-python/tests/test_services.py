import pytest
from datetime import date, timedelta
from services.gamification_service import GamificationService
from services.auth_service import AuthService
from utils.constants import LEVEL_BASE_EXP

def test_calculate_level():
    assert GamificationService.calculate_level(0) == 1
    assert GamificationService.calculate_level(99) == 1
    assert GamificationService.calculate_level(100) == 2
    # Với exponent 1.5: 100 * (2^1.5) = 100 * 2.828 = 282.8
    assert GamificationService.calculate_level(282) == 2
    assert GamificationService.calculate_level(283) == 3

def test_streak_logic():
    # Giả lập logic streak không reset
    from datetime import date, timedelta
    class MockUser:
        def __init__(self):
            self.streak = 6
            self.last_sub_date = date.today() - timedelta(days=1)
            self.exp = 0
            self.monthly_exp = 0

    user = MockUser()
    today = date.today()
    GamificationService.update_streak_and_exp(user, today, 50)

    assert user.streak == 7
    # Bonus 300 + 50 = 350
    assert user.exp == 350
    assert user.last_sub_date == today

def test_calculate_progress(app):
    # Test logic tính tiến độ theo môn học
    from models.database import db, User, Subject, Assignment, Submission
    from services.learning_service import LearningService

    with app.app_context():
        user = User(username="sv1", email="sv1@gmail.com", password="123", role="Student", is_approved=True)
        sub1 = Subject(name="Toán")
        sub2 = Subject(name="Văn")
        db.session.add_all([user, sub1, sub2])
        db.session.commit()

        assign1 = Assignment(title="BT Toán", description="...", due_date=date.today(), subject_id=sub1.id)
        assign2 = Assignment(title="BT Văn", description="...", due_date=date.today(), subject_id=sub2.id)
        db.session.add_all([assign1, assign2])
        db.session.commit()

        # Nộp bài môn Toán và được chấm 8 điểm
        submission = Submission(assignment_id=assign1.id, user_id=user.id, status='Graded', grade=8.0)
        db.session.add(submission)
        db.session.commit()

        progress = LearningService.calculate_progress(user)

        # Kiểm tra kết quả
        assert progress['completed_count'] == 1
        # Toán (8/10) -> 80%
        # Văn (chưa có điểm) -> 0%
        toan_pct = next(s['pct'] for s in progress['subject_progress'] if s['name'] == 'Toán')
        van_pct = next(s['pct'] for s in progress['subject_progress'] if s['name'] == 'Văn')

        assert toan_pct == 80
        assert van_pct == 0
