def test_dashboard_redirect_anonymous(client):
    response = client.get('/dashboard')
    assert response.status_code == 302
    assert '/login' in response.location

def test_login_page_loads(client):
    response = client.get('/login')
    assert response.status_code == 200
    assert b'Login' in response.data or b'\xc4\x90\xc4\x83ng Nh\xe1\xba\xadp' in response.data # Đăng Nhập
